# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
MoonApp::Application.config.secret_token = '6357042c38169f37ad9b875c131c33c91a7d410b61e192150ca97ce969076404b84cc0fad05f8775b622a50d851ab6ca25ca7af900650ffac77bda35fbe5b4d9'
