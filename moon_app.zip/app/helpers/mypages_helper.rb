module MypagesHelper
end
